package com.htx.intelligentstretcher;

import androidx.fragment.app.Fragment;

public class PatientVitals extends Fragment {
}
